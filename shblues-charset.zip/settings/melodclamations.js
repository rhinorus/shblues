var melodclamations = [
    { 
        name: 'Roomservice',
        file: 'data/assets/audio/roses.mp3'
    },
    {
        name: 'Summertime',
        file: 'data/assets/audio/roses.mp3'
    },
    {
        name: 'Sunny',
        file: 'data/assets/audio/roses.mp3'
    }
];